from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import subprocess, tempfile, shutil, uuid

ROOT = Path(__file__).parent
app = FastAPI(title="Lzxia")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

@app.get("/")
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.post("/api/edit")
async def edit_video(file: UploadFile = File(...), prompt: str = Form("")):
    if not file.filename:
        raise HTTPException(400, "Escolha um vídeo.")
    suffix = Path(file.filename).suffix.lower()
    if suffix not in {".mp4", ".mov", ".m4v", ".webm", ".avi"}:
        raise HTTPException(400, "Envie um vídeo MP4, MOV, M4V, WEBM ou AVI.")
    if not shutil.which("ffmpeg"):
        raise HTTPException(500, "FFmpeg não está instalado no servidor.")
    work = Path(tempfile.mkdtemp(prefix="lzxia_"))
    try:
        source = work / ("input" + suffix)
        output = work / "lzxia-edit.mp4"
        content = await file.read()
        if len(content) > 300 * 1024 * 1024:
            raise HTTPException(413, "O vídeo deve ter até 300 MB.")
        source.write_bytes(content)
        p = prompt.lower()
        vf = []
        af = []
        extra = []

        # Simple, real FFmpeg operations selected from the user's natural-language request.
        if "reverse" in p or "ao contrário" in p or "ao contrario" in p:
            vf.append("reverse")
            af.append("areverse")
        if "slow motion" in p or "slowmo" in p or "câmera lenta" in p or "camera lenta" in p or "slow" in p:
            vf.append("setpts=1.5*PTS")
            af.append("atempo=0.6667")
        if "4k" in p or "uhd" in p:
            vf.append("scale=3840:2160:force_original_aspect_ratio=decrease,pad=3840:2160:(ow-iw)/2:(oh-ih)/2")
        if "color grade" in p or "cinemat" in p or "guerreiro" in p:
            vf.append("eq=contrast=1.12:saturation=1.18:brightness=-0.025")
            vf.append(" vignette ")
        if "motion blur" in p or "blur" in p:
            vf.append("gblur=sigma=1.2")
        if "topaz" in p or "qualidade" in p or "melhore" in p:
            # Scaling to source size plus mild denoise/sharpen; not AI upscaling.
            vf.append("hqdn3d=1.5:1.5:6:6")
            vf.append("unsharp=5:5:0.65:3:3:0.25")

        cmd = ["ffmpeg", "-y", "-i", str(source)]
        if vf:
            vf = [f for f in vf if f.strip()]
            cmd += ["-vf", ",".join(vf)]
        if af:
            cmd += ["-af", ",".join(af)]
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(output)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        if result.returncode != 0 or not output.exists():
            raise HTTPException(500, "Falha no processamento. Tente um vídeo menor ou outro formato.")
        return FileResponse(output, media_type="video/mp4", filename="lzxia-edit.mp4", background=None)
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "O vídeo demorou demais para processar.")
    finally:
        # FileResponse needs the output path after the response is sent, so cleanup is not performed here.
        pass
