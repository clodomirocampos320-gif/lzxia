# Lzxia — protótipo com processamento real de vídeo

A interface visual foi mantida. Este projeto adiciona um backend que usa FFmpeg para aplicar alguns efeitos básicos de verdade.

## O que funciona neste protótipo
- Upload de vídeo e retorno de um MP4 processado.
- Reverse (inclui áudio reverso).
- Slow motion básico.
- Saída 4K/UHD por redimensionamento (não cria detalhes reais como um upscaler de IA).
- Ajustes simples de cor para pedidos como “color grade” ou “montagem guerreiro”.
- Desfoque e nitidez/denoise básicos para pedidos “motion blur” e “Topaz/qualidade”.

## Limites importantes
- Isto ainda **não é a CHARKX nem uma IA generativa completa**.
- “Montagem guerreiro” aplica uma colorização básica; não procura automaticamente modelos do CapCut nem replica cortes, transições, música ou keyframes de um template.
- Tracking, Topaz com IA, reconhecimento automático de cenas e sincronização musical ainda não estão implementados.
- O servidor precisa estar ligado para processar vídeos. Um HTML aberto diretamente no celular não consegue executar este backend.

## Como iniciar (computador ou servidor)
1. Instale Python 3.10+ e FFmpeg.
2. Na pasta do projeto:
   `pip install -r requirements.txt`
3. Inicie:
   `uvicorn app:app --host 0.0.0.0 --port 8000`
4. Abra `http://localhost:8000` no navegador.

Para usar pelo Android, hospede este projeto num servidor que permita instalar FFmpeg e mantenha o serviço online. Não coloque chaves secretas no HTML.
